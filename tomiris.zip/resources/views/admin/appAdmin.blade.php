@include('admin.layouts.header')
<div class="container">
    @yield('content')

</div>
@yield('modal')
@include('admin.layouts.footer')
