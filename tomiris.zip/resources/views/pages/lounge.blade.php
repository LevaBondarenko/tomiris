@extends('app')
@section('title','Loungebar')

@section('content')
    <section class="content">
        <div class="container container_white">
            <div class="content_img" style="background:url('../images/ARML8914.jpg') no-repeat 50% 50%"></div>
            <h2 class="news_block">Loungebar</h2>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Asperiores aut beatae consequatur delectus dicta dolorem dolores eaque earum excepturi exercitationem expedita id impedit iure laborum laudantium maxime necessitatibus nihil nobis officia pariatur perferendis ratione repellendus, repudiandae rerum saepe sed sunt temporibus ut voluptate voluptatum! Aut consequuntur dolorum earum nostrum qui?</p>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloribus esse labore quod sit! Excepturi,
                sit!</p>
            <div class="news_box">
                <article class="block_news">
                    <img class="news_img" src="/images/ARML8962.jpg" alt="">
                </article>
                <article class="block_news">
                    <img class="news_img" src="/images/ARML8961.jpg" alt="">
                </article>
                <article class="block_news">
                    <img class="news_img" src="/images/ARML8974.jpg" alt="">
                </article>
            </div>
        </div>
    </section>
@endsection