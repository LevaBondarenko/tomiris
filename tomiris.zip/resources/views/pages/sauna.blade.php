@extends('app')
@section('title','Гостиница')

@section('content')
    <section class="content" style="padding-top: 50px;">
        <div class="container container_white" style="padding: 50px;">
            <h1 style="border: none;">Скоро открытие!</h1>

        </div>
    </section>
@endsection