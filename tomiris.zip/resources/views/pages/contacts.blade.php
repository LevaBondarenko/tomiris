@extends('app')
@section('title','Loungebar')

@section('content')
    <section class="content" style="padding-top: 100px;">
        <div class="container container_white">
            <h2 class="news_block">Контакты</h2>
            <div class="left" style="padding: 150px 50px 50px 50px; width: 540px;">
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Atque cum, delectus eaque esse excepturi expedita fugit ipsa, itaque laudantium magni minus modi provident quod ratione rem repudiandae sit temporibus unde. Atque corporis debitis dolor doloremque impedit iste laboriosam optio reprehenderit sit, suscipit totam voluptas, voluptate. Adipisci aliquid animi aspernatur debitis, delectus dolorem ea eos, excepturi id inventore ipsum labore minima mollitia natus neque sed sit tempore? Ab aliquam assumenda blanditiis consequatur dignissimos dolor doloremque earum facilis inventore ipsa itaque iure labore neque nihil nostrum, possimus ratione reprehenderit rerum sapiente sed similique tenetur ullam voluptas voluptates voluptatum! Dolorum fugiat optio qui.</p>
            </div>
            <div class="mini-map">
                <script type="text/javascript" charset="utf-8" async src="https://api-maps.yandex.ru/services/constructor/1.0/js/?sid=MLLY4KnoXvkRqu7vjZC9pkvISt4ZLoqY&width=100%&height=100%&lang=ru_RU&sourceType=constructor&scroll=true"></script>
            </div>
        </div>
    </section>
@endsection