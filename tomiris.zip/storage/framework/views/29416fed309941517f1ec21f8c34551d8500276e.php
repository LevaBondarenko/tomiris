<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo $__env->yieldContent('title'); ?></title>


    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.0/css/bootstrap.css">
    <link rel="stylesheet" href="assets/css/screen.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.4/jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.5/js/bootstrap.js"></script>



</head>
<body>
<header class="header" style="height: 60px;">
    <div class="container">
        <?php if(\Illuminate\Support\Facades\Auth::check()): ?>
            <span style="float: left;">Вы авторизованны</span>
        <?php endif; ?>
        <ul class="header__navigation" style="margin: 20px 0 0 0;">

            <?php if(\Illuminate\Support\Facades\Auth::check()): ?>
                <li><a href="/admin">Новости</a></li>
                <li><a href="/">На сайт</a></li>
            <?php else: ?>

            <?php endif; ?>
            <?php if(\Illuminate\Support\Facades\Auth::check()): ?>
                <a href="<?php echo e(url('logout/')); ?>">Выйти</a>
            <?php else: ?>
                <a href="<?php echo e(url('admin/')); ?>">Вход</a>
            <?php endif; ?>
        </ul>
    </div>
</header>