<?php $__env->startSection('title','Новости'); ?>
<?php $__env->startSection('content'); ?>
    <h1>Добавление записей</h1>


    <?php echo Form::open(array('route' => 'save','method'=>'post','enctype'=>'multipart/form-data')); ?>

    <?php echo Form::label('date','Дата'); ?>

    <input type="date" name="date" id="" required>
    <br>
    <?php echo Form::label('title','Заголовкок'); ?>

    <?php echo Form::text('title','',['class'=>'form-control'],['required' => 'required']); ?>

    <br>
    <?php echo Form::label('preview_text','Первичный текст'); ?>

    <?php echo Form::text('preview_text','',['class'=>'form-control'],['required' => 'required']); ?>

    <br>
    <?php echo Form::label('detail_text','Детальный текст'); ?>

    <?php echo Form::text('detail_text','',['class'=>'form-control'],['required' => 'required']); ?>

    <br>
    <?php echo Form::label('image','Изображение'); ?>

    <?php echo Form::file('image',['class'=>'form-control']); ?>

    <input type="hidden" value="<?php echo e(csrf_token()); ?>">
    <br>
    <?php echo Form::submit('Отправить',['class'=>'btn btn-default']); ?>

    <?php echo Form::close(); ?>


    <br>
    <br>
    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>
    <h1>Все записи</h1>
    <section class="box_news" style="background: #ccc;">
        <?php foreach($news as $item): ?>
            <article class="block_news" style="width: 100%; border: 1px solid #111; margin: 10px 0; padding: 20px;">
                <div class="box-news_content">
                    <span style="float: left; margin-right: 10px"><?php echo e($item->id); ?></span>
                    <img src="<?php echo e($item->img_src); ?>" alt="" style="width: 50px;">
                    <span class="news_date"><?php echo e($item->date); ?></span>
                    <h4 class="title_news"><?php echo e($item->title); ?></h4>
                    <p class="content_news"><?php echo e($item->preview_text); ?></p>
                </div>
                <div class="panel_edit" style="float: right">
                    <a class="btn bg-info" href="admin/news/update/<?php echo e($item->id); ?>" onClick="return window.confirm('Вы действительно хотите изменить?')">Редактировать</a>
                    <br>
                    <br>
                    <a class="btn btn-danger" onClick="return window.confirm('Вы действительно хотите удалить запись?')" href="admin/news/delete/<?php echo e($item->id); ?>">Удалить</a>


                </div>
            </article>
        <?php endforeach; ?>
    </section>
<?php echo e($news->links()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.appAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>