<?php $__env->startSection('title','Гостиница'); ?>

<?php $__env->startSection('content'); ?>
    <section class="content" style="padding-top: 50px;">
        <div class="container container_white" style="padding: 50px;">
            <h1 style="border: none;">Скоро открытие!</h1>

        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>