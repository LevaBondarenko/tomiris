<footer>
    <div class="container">



        <div class="left">
            <h3>АДРЕС</h3>
            <p>Казахстан, Астана, 010000</p>
            <p>Кургальджинское шоссе, 9</p>



        </div>

        <div class="social" >
            <ul style="margin: 70px 0 0 0;">
                <li><?php echo e(date("Y")); ?> &copy; <a href="http://lioncompany.kz/">Created LIONCOMPANY.KZ</a></li>
            </ul>
        </div>
        <div class="right">

            <h3>Ресторан <br> Lounge bar</h3>
            <p>тел.: +7 7172 790027</p>
            <p> моб.:+7 775 197 9013</p>
            <p>с 11:00 до 03:00</p>
        </div>
    </div>
    <section class="clear"></section>
</footer>
<script src="https://cdnjs.cloudflare.com/ajax/libs/prefixfree/1.0.7/prefixfree.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.4/jquery.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.5/js/bootstrap.js"></script>
<script src="assets/js/js.js"></script>
</body>
</html>