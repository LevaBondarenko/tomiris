<?php if(session('status')): ?>
    <div class="alert alert-success">
        <?php echo e(session('status')); ?>

    </div>
<?php endif; ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <h1>Томирис</h1>
            <?php foreach($errors->all() as $error): ?>
                <?php if($error == 'The password field is required.'): ?>
                    <div class="alert alert-success">
                        Вы не ввели пароль
                    </div>
                <?php endif; ?>
                <?php if($error == 'The email field is required.'): ?>
                    <div class="alert alert-success">
                        Вы не ввели логин
                    </div>
                <?php endif; ?>

            <?php endforeach; ?>
<?php echo Form::open(array('route'=>'postLogin','method'=>'post')); ?>

                <label for="email">Логин</label>
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            <input type="text" name="email" class="form-control">
                <label for="password">Пароль</label>
            <input type="password" name="password" class="form-control">
            <br>
<?php echo Form::submit('Войти',['class'=>'btn btn-info']); ?>

            <?php echo Form::close(); ?>

             </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.appAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>