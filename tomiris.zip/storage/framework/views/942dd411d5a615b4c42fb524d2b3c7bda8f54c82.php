<?php $__env->startSection('title','Главная страница'); ?>


<?php $__env->startSection('content'); ?>
    <section class="firstscreen">
        <div class="bg_black">
            <div class="container">
                <img src="images/logo.svg" alt="">
                    <p><?php echo e($content['0']['title']); ?></p>
            </div>
        </div>
    </section>

    <section class="brow">
        <div class="container">
            <h2 class="news_block" style="padding-top: 30px;">НАШИ УСЛУГИ</h2>
            <img src="images/lojka.png" class="lojka" alt="">
            <div class="block">
                <article class="blocks">
                    <div class="top_block">
                        <img class="blocks__img" src="images/tray.svg" alt="">
                        <h4>Ресторан</h4>
                    </div>
                    <div class="sub_block">
                        <p>
                            <?php echo e($content['0']['restoran']); ?>

                        </p>
                    </div>
                </article>
                <article class="blocks">
                    <div class="top_block">
                        <img class="blocks__img" src="images/hookah.svg" alt="">
                        <h4>кальян</h4>
                    </div>
                    <div class="sub_block">
                        <p><?php echo e($content['0']['kalyan']); ?></p>
                    </div>
                </article>
                <article class="blocks">
                    <div class="top_block">
                        <img class="blocks__img" src="images/bed.svg" alt="">
                        <h4>гостиница</h4>
                    </div>
                    <div class="sub_block">
                        <p><?php echo e($content['0']['hotel']); ?></p>
                    </div>
                </article>
                <article class="blocks">
                    <div class="top_block">
                        <img height="110px" style="    margin-top: 7px;margin-bottom: 10px;" class="blocks__img" src="images/bath.svg" alt="">
                        <h4>сауна</h4>
                    </div>
                    <div class="sub_block">
                        <p><?php echo e($content['0']['bathroom']); ?></p>
                    </div>
                </article>
            </div>
            <img src="images/vilka.png" class="vilka" alt="">
        </div>
    </section>
    <section class="news">
        <div class="container news_container">
            <h2 class="news_block">
                Последние новости.
            </h2>

            <section class="box_news">
                <?php foreach($news as $item): ?>
                    <article class="block_news">
                        <span class="news_date"><?php echo e($item->date); ?></span>
                        <h4 class="title_news"><?php echo e(substr($item->title,0,100)); ?></h4>
                        <p class="content_news"><?php echo e($item->preview_text); ?></p>
                        <button class="btn news_more" data-toggle="modal" data-target="#modal-<?php echo e($item->id); ?>" >Подробнее</button>

                        <div class="modal fade" id="modal-<?php echo e($item->id); ?>">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <?php if(!empty($item['img_src'])): ?>
                                        <div class="img-responsive" style="background: url('/<?php echo e($item->img_src); ?>') no-repeat; -webkit-background-size:100% 100% ;background-size: 100% 100%;    height: 300px;">
                                            <div class="modal-header">
                                                <span><?php echo e($item->title); ?></span>
                                              <button class="close" type="button" data-dismiss="modal">X</button>
                                            </div>
                                        </div>
                                        <?php else: ?>
                                        <div class="modal-header" style="background: #000;">
                                            <span><?php echo e($item->title); ?></span>
                                            <button class="close" type="button" data-dismiss="modal">X</button>
                                        </div>
                                    <?php endif; ?>
                                    <div class="modal-body">
                                        <p><b><?php echo e($item->preview_text); ?></b></p>
                                        <p><?php echo e($item->detail_text); ?></p>
                                    </div>
                                    <div class="modal-footer">
                                        <span><?php echo e($item->date); ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </article>

                <?php endforeach; ?>
            </section>

        </div>
        <section class="clear"></section>

    </section>
    <section class="interier">
        <div class="container">
            <h2 class="news_block">
                Наш интерьер
            </h2>
            <ul id="carousel" class="owl-carousel carousel">
                <li><img src="/images/ARML8905.jpg" width="300" height="200" alt="Owl_1" /></li>
                <li><img src="/images/ARML8920.jpg" width="300" height="200" alt="Owl_2" /></li>
                <li><img src="/images/ARML8935.jpg" width="300" height="200" alt="Owl_3" /></li>
                <li><img src="/images/ARML8937.jpg" width="300" height="200" alt="Owl_4" /></li>
                <li><img src="/images/ARML8966.jpg" width="300" height="200" alt="Owl_5" /></li>
                <li><img src="/images/ARML8815.jpg" width="300" height="200" alt="Owl_6" /></li>
                <li><img src="/images/ARML8935.jpg" width="300" height="200" alt="Owl_7" /></li>
                <li><img src="/images/ARML8937.jpg" width="300" height="200" alt="Owl_8" /></li>
            </ul>
        </div>
    </section>
    <section class="news">
        <div class="container news_container">
            <h2 class="news_block">
                Наши партнеры
            </h2>

            <section class="box_news">
                <ul id="carousel-2" class="owl-carousel carousel">
                    <li><img src="/images/ExpressAccountingSolutionsLtd-Accountancy-Firm-Logo-Design.jpg" width="100" height="100" alt="Owl_1" /></li>
                    <li><img src="/images/11.jpg" width="100" height="100" alt="Owl_2" /></li>
                    <li><img src="/images/images1).jpg" width="100" height="100" alt="Owl_3" /></li>
                    <li><img src="/images/logo-moda.jpg" width="100" height="100" alt="Owl_4" /></li>
                    <li><img src="/images/Uber-Logo.jpg" width="100" height="100" alt="Owl_5" /></li>
                    <li><img src="/images/images.jpg" width="100" height="100" alt="Owl_6" /></li>
                </ul>
            </section>

        </div>
        <section class="clear"></section>

    </section>
    <section class="news brown">
        <div class="container news_container">
            <h2 class="news_block">
                Контакты
            </h2>


                <div class="left">
                    <h3>АДРЕС</h3>
                    <p>Казахстан, Астана, 010000</p>
                    <p>Кургальджинское шоссе, 9</p>

                    <h3>Гостиница</h3>
                    <p> тел.: +7 7172 790025</p>
                    <p>моб.: +7 707 555 5950</p>
                    <p>Круглосуточно</p>


                </div>

            <div class="social">
                <ul>
                    <li><a href="<?php echo e($content['0']['vk']); ?>"><img src="/images/vk.png" alt=""></a></li>
                    <li><a href="<?php echo e($content['0']['insta']); ?>"><img src="/images/insta.png" alt=""></a></li>
                    <li><a href="<?php echo e($content['0']['fb']); ?>"><img src="/images/fb.png" alt=""></a></li>
                </ul>
            </div>
            <div class="right">

                <h3>Ресторан <br> Lounge bar</h3>
                <p>тел.: +7 7172 790027</p>
                <p> моб.:+7 775 197 9013</p>
                <p>с 11:00 до 03:00</p>
            </div>
        </div>
        <section class="clear"></section>

    </section>
    <section>
        <script type="text/javascript" charset="utf-8" async src="https://api-maps.yandex.ru/services/constructor/1.0/js/?sid=MLLY4KnoXvkRqu7vjZC9pkvISt4ZLoqY&width=100%&height=400&lang=ru_RU&sourceType=constructor&scroll=true"></script>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>