<?php $__env->startSection('title','Новости'); ?>
<?php $__env->startSection('content'); ?>
    <h1>Редактирование</h1>
    <?php echo Form::open(array('route' => 'adminUpdateSave','method'=>'post','enctype'=>'multipart/form-data')); ?>

        <input type="hidden" name="id" value="<?php echo e($new->id); ?>">
        <label for="date">Дата</label>
        <input type="date" name="date" id="" value="<?php echo e($new->date); ?>">
        <br>
        <label for="title">Заголовок</label>
        <input type="text" class="form-control" name="title" value="<?php echo e($new->title); ?>"><br>
        <br>
        <label for="title">Краткое описание</label>
        <input type="text" class="form-control" name="preview_text" value="<?php echo e($new->preview_text); ?>">
        <br>
        <label for="title">Детальное описание</label>
        <input type="text" class="form-control" name="detail_text" value="<?php echo e($new->detail_text); ?>">
        <br>
        <label for="title">Картинка заголовка</label>
        <?php if(isset($new->img_src)): ?>
            <img src="/<?php echo e($new->img_src); ?>" style="width: 150px;" alt="">
        <?php endif; ?>
        <input type="hidden" value="<?php echo e(csrf_token()); ?>" name="_token">
        <input type="file"  name="image" value="/<?php echo e($new->img_src); ?>">
        <br>
        <?php echo Form::submit('Сохранить',['class'=>'btn btn-info']); ?>

    <?php echo Form::close(); ?>

    <br>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.appAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>