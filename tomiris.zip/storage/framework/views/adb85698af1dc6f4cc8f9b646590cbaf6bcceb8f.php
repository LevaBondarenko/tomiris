<?php $__env->startSection('title','Новости'); ?>

<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="container container_white">
            <div class="content_img" style="background:url('../images/ARML9740.jpg') no-repeat 50% 55%"></div>
            <h2 class="news_block">Новости</h2>
            <div class="news_box">
                <?php foreach($news as $item): ?>
                    <article class="block_news">
                        <?php if(!empty($item->img_src)): ?>
                        <img data-toggle="modal" data-target="#modal-<?php echo e($item->id); ?>" class="news_img" src="/<?php echo e($item->img_src); ?>" alt="">
                        <?php else: ?>
                            <div class="news_img none"></div>
                        <?php endif; ?>
                        <span class="news_date"><?php echo e($item->date); ?></span>
                        <h4 class="title_news"><?php echo e($item->title); ?></h4>
                        <p class="content_news"><?php echo e($item->preview_text); ?></p>
                        <button class="news_more" data-toggle="modal" data-target="#modal-<?php echo e($item->id); ?>">Подробнее</button>
                            <div class="modal fade" id="modal-<?php echo e($item->id); ?>">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <?php if(!empty($item['img_src'])): ?>
                                            <div class="img-responsive" style="background: url('/<?php echo e($item->img_src); ?>') no-repeat; -webkit-background-size:100% 100% ;background-size: cover;    height: 300px;">
                                                <div class="modal-header">
                                                    <span><?php echo e($item->title); ?></span>
                                                    <button class="close" type="button" data-dismiss="modal">X</button>
                                                </div>
                                            </div>
                                        <?php else: ?>
                                            <div class="modal-header" style="background: #000;">
                                                <span><?php echo e($item->title); ?></span>
                                                <button class="close" type="button" data-dismiss="modal">X</button>
                                            </div>
                                        <?php endif; ?>
                                        <div class="modal-body">
                                            <p><b><?php echo e($item->preview_text); ?></b></p>
                                            <p><?php echo e($item->detail_text); ?></p>
                                        </div>
                                        <div class="modal-footer">
                                            <span><?php echo e($item->date); ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    </article>

                <?php endforeach; ?>
            </div>
            <div class="clear"></div>
<?php echo e($news->render()); ?>

        </div>

    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>